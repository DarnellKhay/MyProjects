//
//  ThirdViewController.swift
//  Health1.0
//
//  Created by Darnell Khay on 9/4/20.
//  Copyright © 2020 Darnell Khay. All rights reserved.
//

import UIKit


class ThirdViewController: UIViewController{
    override func viewDidLoad() {
         super.viewDidLoad()
             }
    
}
