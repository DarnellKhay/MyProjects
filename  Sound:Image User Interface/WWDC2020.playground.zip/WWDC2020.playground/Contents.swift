// Darnell Khay WWDC2020 Swift Student Challenge
import UIKit
import PlaygroundSupport
import AVFoundation


// The main user interface that presents all the buttons
class mainViewController: UIViewController {
    
    override func viewDidLoad() {
        title = "Click the buttons!"
        
        // Main view controller buttons
        view.addSubview(button)
        view.addSubview(button3)
        view.addSubview(button4)
        view.addSubview(button5)
        view.addSubview(button6)
        view.addSubview(button7)
        view.addSubview(button8)
    }
}

// Sound Effects
// Credits to Mojang and Microsoft for the sound effects
let eatSound = URL(fileURLWithPath: Bundle.main.path(forResource: "eatingSound", ofType: "mp3")!)
var soundPlayer = AVAudioPlayer()
let mysteryNoise = URL(fileURLWithPath: Bundle.main.path(forResource: "mysterysound", ofType: "mp3")!)



// The button that appears in the new view controller that is displayed after any button is clicked from the main view controller
// When clicked, the main view controller is displayed again
var access2: buttonAction2 = buttonAction2(nibName: nil, bundle: nil)
var button2 = access2.Button2
class buttonAction2: UIViewController {
    var Button2: UIButton {
        let myButton2 = UIButton(frame: CGRect(x: 130, y:100, width: 100, height:50))
        myButton2.translatesAutoresizingMaskIntoConstraints = false
        myButton2.setTitle("Go Back", for: .normal)
        myButton2.backgroundColor = UIColor.black
        myButton2.setTitleColor(UIColor.white, for: .normal)
        myButton2.layer.cornerRadius = 10
        myButton2.addTarget(self, action: #selector(goBack), for: .touchUpInside)
        myButton2.addTarget(self, action: #selector(endSound), for: .touchUpInside)
        return myButton2
    }
    @objc func goBack(_sender: UIButton!){
        PlaygroundPage.current.liveView = nav
    }
    // Stop sound effect when "Go Back" button is pressed
    @IBAction func endSound(sender: UIButton!) {
          do {
               soundPlayer = try AVAudioPlayer(contentsOf: eatSound)
               soundPlayer.stop()
          } catch {
            // return nothing if do fails
             return
        }
    }
}

// Button #1
// When clicked it will display a new view controller
// Color: Red
var access: buttonAction = buttonAction(nibName: nil, bundle: nil)
var button = access.Button1
class buttonAction: UIViewController {
    var Button1: UIButton {
        let myButton = UIButton(frame: CGRect(x: 50, y: 100, width: 100, height: 50))
               myButton.translatesAutoresizingMaskIntoConstraints = true
               myButton.setTitle("1", for: .normal)
               myButton.backgroundColor = UIColor.red
               myButton.setTitleColor(UIColor.white, for: .normal)
               myButton.layer.cornerRadius = 8
               myButton.addTarget(self, action: #selector(newView), for: .touchUpInside)
        myButton.addTarget(self, action: #selector(playSound), for: .touchUpInside)
              return myButton
       }
    @objc func newView(_sender: UIButton!){
        PlaygroundPage.current.liveView = secondViewController()
    }
    // Play sound effect when Button #1 is pressed
    @IBAction func playSound(sender: UIButton!) {
        do {
             soundPlayer = try AVAudioPlayer(contentsOf: eatSound)
             soundPlayer.play()
        } catch {
            // return nothing if do fails
           return
        }
    }
   
}

// The view controller that is displayed after Button #1 is clicked
// Displays an image of an apple, a button, a label and audio
class secondViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let label = UILabel(frame: CGRect(x: 140, y: 50, width: 200, height: 50))
        label.text = "An Apple!"
        
        
        let apple = UIImage(named: "Apple.jpg")
        let appleImageView: UIImageView = UIImageView()
        appleImageView.contentMode = UIView.ContentMode.scaleAspectFit
        appleImageView.frame.size.width = 300
        appleImageView.frame.size.height = 300
        appleImageView.center = self.view.center
        appleImageView.image = apple
        
        
        view.addSubview(appleImageView)
        view.addSubview(button2)
        view.addSubview(label)
    }
}

// Button #2
// When clicked it will display a new view controller
// Color: Green
var access3: buttonAction3 = buttonAction3(nibName: nil, bundle: nil)
var button3 = access3.Button3
class buttonAction3: UIViewController {
    var Button3: UIButton {
        let myButton3 = UIButton(frame: CGRect(x: 200, y: 100, width: 100, height: 50))
               myButton3.translatesAutoresizingMaskIntoConstraints = true
               myButton3.setTitle("2", for: .normal)
               myButton3.backgroundColor = UIColor.green
               myButton3.setTitleColor(UIColor.black, for: .normal)
               myButton3.layer.cornerRadius = 8
               myButton3.addTarget(self, action: #selector(newView), for: .touchUpInside)
               myButton3.addTarget(self, action: #selector(playSound), for: .touchUpInside)
              return myButton3
       }
    @objc func newView(_sender: UIButton!){
        PlaygroundPage.current.liveView = thirdViewController()
    }
    // Play sound effect when Button #2 is preesed
    @IBAction func playSound(sender: UIButton!) {
          do {
               soundPlayer = try AVAudioPlayer(contentsOf: eatSound)
               soundPlayer.play()
          } catch {
            // return nothing if do fails
             return
        }
    }
}

// The view controller that is displayed after Button #2 is clicked
// Displays an image of a pear, a button, a label and audio
class thirdViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let label2 = UILabel(frame: CGRect(x: 140, y: 50, width: 200, height: 50))
        label2.text = "A Pear!"
        
        
        let pear = UIImage(named: "pear.png")
        let pearImageView: UIImageView = UIImageView()
        pearImageView.contentMode = UIView.ContentMode.scaleAspectFit
        pearImageView.frame.size.width = 300
        pearImageView.frame.size.height = 400
        pearImageView.center = self.view.center
        pearImageView.image = pear
        
        
        view.addSubview(pearImageView)
        view.addSubview(button2)
        view.addSubview(label2)
    }
}

// Button #3
// When clicked it will display a new view controller
// Color: Purple
var access4: buttonAction4 = buttonAction4(nibName: nil, bundle: nil)
var button4 = access4.Button4
class buttonAction4: UIViewController {
    var Button4: UIButton {
        let myButton4 = UIButton(frame: CGRect(x: 50, y: 200, width: 100, height: 50))
               myButton4.translatesAutoresizingMaskIntoConstraints = true
               myButton4.setTitle("3", for: .normal)
               myButton4.backgroundColor = UIColor.purple
               myButton4.setTitleColor(UIColor.white, for: .normal)
               myButton4.layer.cornerRadius = 8
               myButton4.addTarget(self, action: #selector(newView), for: .touchUpInside)
               myButton4.addTarget(self, action: #selector(playSound), for: .touchUpInside)
              return myButton4
       }
    @objc func newView(_sender: UIButton!){
        PlaygroundPage.current.liveView = fourthViewController()
    }
    // Play sound effect when Button #3 is pressed
   @IBAction func playSound(sender: UIButton!) {
            do {
                 soundPlayer = try AVAudioPlayer(contentsOf: eatSound)
                 soundPlayer.play()
            } catch {
                // return nothing if do fails
               return
          }
      }
}
// The view controller that is displayed after Button #3 is clicked
// Displays an image of grapes, a button, a label and audio
class fourthViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let label3 = UILabel(frame: CGRect(x: 140, y: 50, width: 200, height: 50))
        label3.text = "Grapes!"
        
        
        let grapes = UIImage(named: "grapes.jpg")
        let grapesImageView: UIImageView = UIImageView()
        grapesImageView.contentMode = UIView.ContentMode.scaleAspectFit
        grapesImageView.frame.size.width = 300
        grapesImageView.frame.size.height = 500
        grapesImageView.center = self.view.center
        grapesImageView.image = grapes
        
        
        view.addSubview(grapesImageView)
        view.addSubview(button2)
        view.addSubview(label3)
    }
}

// Button #4
// When clicked it will display a new view controller
// Color: Orange
var access5: buttonAction5 = buttonAction5(nibName: nil, bundle: nil)
var button5 = access5.Button5
class buttonAction5: UIViewController {
    var Button5: UIButton {
        let myButton5 = UIButton(frame: CGRect(x: 200, y: 200, width: 100, height: 50))
               myButton5.translatesAutoresizingMaskIntoConstraints = true
               myButton5.setTitle("4", for: .normal)
               myButton5.backgroundColor = UIColor.orange
               myButton5.setTitleColor(UIColor.white, for: .normal)
               myButton5.layer.cornerRadius = 8
               myButton5.addTarget(self, action: #selector(newView), for: .touchUpInside)
        myButton5.addTarget(self, action: #selector(playSound), for: .touchUpInside)
              return myButton5
       }
    @objc func newView(_sender: UIButton!){
        PlaygroundPage.current.liveView = fifthViewController()
    }
    // Play sound effect when Button #4 is pressed
    @IBAction func playSound(sender: UIButton!) {
          do {
               soundPlayer = try AVAudioPlayer(contentsOf: eatSound)
               soundPlayer.play()
          } catch {
            // return nothing if do fails
             return 
        }
    }
   
}

// The view controller that is displayed after Button #4 is clicked
// Displays an image of oranges, a button, a label, and audio
class fifthViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let label4 = UILabel(frame: CGRect(x: 140, y: 50, width: 200, height: 50))
        label4.text = "Oranges!"
        
        
        let orange = UIImage(named: "orange.jpg")
        let orangeImageView: UIImageView = UIImageView()
        orangeImageView.contentMode = UIView.ContentMode.scaleAspectFit
        orangeImageView.frame.size.width = 300
        orangeImageView.frame.size.height = 500
        orangeImageView.center = self.view.center
        orangeImageView.image = orange
        
        
        view.addSubview(orangeImageView)
        view.addSubview(button2)
        view.addSubview(label4)
    }
}

// Button #5
// When clicked it will display a new view controller
// Color: Yellow
var access6: buttonAction6 = buttonAction6(nibName: nil, bundle: nil)
var button6 = access6.Button6
class buttonAction6: UIViewController {
    var Button6: UIButton {
        let myButton6 = UIButton(frame: CGRect(x: 50, y: 300, width: 100, height: 50))
               myButton6.translatesAutoresizingMaskIntoConstraints = true
               myButton6.setTitle("5", for: .normal)
               myButton6.backgroundColor = UIColor.yellow
               myButton6.setTitleColor(UIColor.black, for: .normal)
               myButton6.layer.cornerRadius = 8
               myButton6.addTarget(self, action: #selector(newView), for: .touchUpInside)
               myButton6.addTarget(self, action: #selector(playSound), for: .touchUpInside)
              return myButton6
       }
    @objc func newView(_sender: UIButton!){
        PlaygroundPage.current.liveView = sixthViewController()
    }
    // Play sound effect when Button #5 is pressed
   @IBAction func playSound(sender: UIButton!) {
         do {
              soundPlayer = try AVAudioPlayer(contentsOf: eatSound)
              soundPlayer.play()
         } catch {
           // return nothing if do fails
            return
       }
   }
}

// The view controller that is displayed after Button #5 is clicked
// Displays an image of bananas, a button, a label and audio
class sixthViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let label5 = UILabel(frame: CGRect(x: 140, y: 50, width: 200, height: 50))
        label5.text = "Banana!"
        
        
        let banana = UIImage(named: "banana.jpg")
        let bananaImageView: UIImageView = UIImageView()
        bananaImageView.contentMode = UIView.ContentMode.scaleAspectFit
        bananaImageView.frame.size.width = 300
        bananaImageView.frame.size.height = 500
        bananaImageView.center = self.view.center
        bananaImageView.image = banana
        
        
        view.addSubview(bananaImageView)
        view.addSubview(button2)
        view.addSubview(label5)
    }
}

// Button #6
// When clicked it will display a new view controller
// Color: Blue
var access7: buttonAction7 = buttonAction7(nibName: nil, bundle: nil)
var button7 = access7.Button7
class buttonAction7: UIViewController {
    var Button7: UIButton {
        let myButton7 = UIButton(frame: CGRect(x: 200, y: 300, width: 100, height: 50))
               myButton7.translatesAutoresizingMaskIntoConstraints = true
               myButton7.setTitle("6", for: .normal)
               myButton7.backgroundColor = UIColor.blue
               myButton7.setTitleColor(UIColor.white, for: .normal)
               myButton7.layer.cornerRadius = 8
               myButton7.addTarget(self, action: #selector(newView), for: .touchUpInside)
               myButton7.addTarget(self, action: #selector(playSound), for: .touchUpInside)
              return myButton7
       }
    @objc func newView(_sender: UIButton!){
        PlaygroundPage.current.liveView = seventhViewController()
    }
    // Play sound effect when Button #6 is pressed
   @IBAction func playSound(sender: UIButton!) {
         do {
              soundPlayer = try AVAudioPlayer(contentsOf: eatSound)
              soundPlayer.play()
         } catch {
           // return nothing if do fails
            return
       }
   }
}

// The view controller that is displayed after Button #6 is clicked
// Displays an image of blueberries, a button, a label, and audio
class seventhViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let label6 = UILabel(frame: CGRect(x: 140, y: 50, width: 200, height: 50))
        label6.text = "Blueberries!"
        
        
        let blueBerry = UIImage(named: "blueberries.jpg")
        let blueBerryImageView: UIImageView = UIImageView()
        blueBerryImageView.contentMode = UIView.ContentMode.scaleAspectFit
        blueBerryImageView.frame.size.width = 300
        blueBerryImageView.frame.size.height = 500
        blueBerryImageView.center = self.view.center
        blueBerryImageView.image = blueBerry
        
        
        view.addSubview(blueBerryImageView)
        view.addSubview(button2)
        view.addSubview(label6)
    }
}


// Mystery Button
// When clicked it will display a new view controller
// Color: Black
var access8: buttonAction8 = buttonAction8(nibName: nil, bundle: nil)
var button8 = access8.Button8
class buttonAction8: UIViewController {
    var Button8: UIButton {
        let myButton8 = UIButton(frame: CGRect(x: 120, y: 375, width: 100, height: 100))
               //myButton8.translatesAutoresizingMaskIntoConstraints = true
               myButton8.setTitle("???", for: .normal)
               myButton8.backgroundColor = UIColor.black
               myButton8.setTitleColor(UIColor.white, for: .normal)
               myButton8.layer.cornerRadius = 8
               myButton8.addTarget(self, action: #selector(newView), for: .touchUpInside)
               myButton8.addTarget(self, action: #selector(playSound), for: .touchUpInside)
              return myButton8
       }
    @objc func newView(_sender: UIButton!){
        PlaygroundPage.current.liveView = mysteryViewController()
    }
    // Play sound effect when Button #6 is pressed
   @IBAction func playSound(sender: UIButton!) {
         do {
              soundPlayer = try AVAudioPlayer(contentsOf: mysteryNoise)
              soundPlayer.play()
         } catch {
           // return nothing if do fails
            return
       }
   }
}

// The view controller that is displayed after the "???" Button is clicked
// Displays a "mystery" image, a button, label and audio
class mysteryViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let label7 = UILabel(frame: CGRect(x: 50, y: 50, width: 500, height: 50))
        label7.text = "Oops, didn't mean to scare you!"
        label7.textColor = UIColor.white
        
       let mystery = UIImageView(frame: UIScreen.main.bounds)
       mystery.image = UIImage(named: "mystery.jpg")
       mystery.contentMode =  UIView.ContentMode.scaleAspectFill
       self.view.insertSubview(mystery, at: 0)
    
        view.addSubview(mystery)
        view.addSubview(button2)
        view.addSubview(label7)
    }
}




// Displaying the main view controller which is the beginning of the user interface
let main = mainViewController()
let nav = UINavigationController(rootViewController: main)
PlaygroundPage.current.liveView = nav


