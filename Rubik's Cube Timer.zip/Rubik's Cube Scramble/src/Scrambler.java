import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.StringJoiner;


import javax.swing.JSpinner;
import javax.swing.JLabel;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.JSlider;
import javax.swing.SpringLayout;
import javax.swing.SpinnerNumberModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.Timer;
import javax.swing.SwingConstants;
/**
 * 
 * @author darnellkhay
 *
 * This program provides a basic GUI for those who have interests in becoming a better cuber. 
 * 
 * Scrambles are provided for the standard 3x3 Rubik's Cube at random in which the user can then replicate on their own cube. 
 * Once the cube is mixed up, the user may hit the green button to begin the timer (timed in seconds) and then hit the red button once they have completed solving.
 * 
 * In case a user needs reference to what the symbols in the scramble mean: 
 * F - Front
 * B - Back
 * D - Down
 * U - Up
 * L - Left
 * R- Right
 * 
 * An apostrophe (') indicates that the face must be rotated counterclockwise, otherwise rotate it clockwise. 
 * The number 2 signifies that the face must be rotated clockwise twice. 
 *
 * Happy Cubing!
 */
public class Scrambler extends JFrame {



	 // States of a Scramble object
	
	// ArrayList to hold all possible moves to scramble a standard 3x3 cube
	private ArrayList<String> moves;
	
	
	// ArrayList to hold a series of moves that will produce the scramble pattern for user
	private ArrayList<String> scramble;
	
	// ArrayList to hold the recorded times 
	private ArrayList<Double> times;
	
	// To display the average within 3 decimal places
	private static DecimalFormat d = new DecimalFormat("#.###");
	
	// Counter
	private int count = 0;
	 
	
	 // Elements of the GUI
	 protected JLabel scrambleLabel;
	 protected JButton startButton;
	 protected Timer timer;
	 protected JLabel timerLabel;
	 protected JButton stopButton;
	 protected JLabel averageTimeLabel;
	 protected JLabel instructionLabel;

	 
	// Default constructor of a Scramble object
	public Scrambler() {
		super();
	
		// initialize Arraylist moves
		moves = new ArrayList<String>();
		
		// adding moves that involve one rotation, 
		// clockwise and counterclockwise to the ArrayList moves 
		moves.add("F");
		moves.add("F'");
		moves.add("B");
		moves.add("B'");
		moves.add("D");
		moves.add("D'");
		moves.add("R");
		moves.add("R'");
		moves.add("L");
		moves.add("L'");
		moves.add("U");
		moves.add("U'"); 
		
		//adding moves that involve two rotations to the ArrayList moves
		moves.add("F2");
		moves.add("B2");
		moves.add("U2");
		moves.add("D2");
		moves.add("L2");
		moves.add("R2");
		
		
		// Shuffle the ArrayList moves to create more randomness 
		Collections.shuffle(moves);
		
		// initialize ArrayList scramble 
		scramble = new ArrayList<String>();
		
	
		// Randomly add in moves to create a scramble of 20 moves
		for(int i = 0; i < 20; i++) {
			scramble.add(moves.get(pickMoveFromList(18)));
		}
		
		
		// Iterating through ArrayList scramble 
		for(int i = 0; i < scramble.size()-1; i++) {
			
			// If two moves in a row involve the same face, replace one of the moves randomly to another face
				if(scramble.get(i).charAt(0) == scramble.get(i+1).charAt(0)) {
					scramble.set(i, moves.get(pickMoveFromList(18)));
			}
		}
		
		
		/*
		 * Setting up GUI
		 */
		 
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 587, 363);
		getContentPane().setLayout(null);
		
		
		// JLabel to present the scramble on GUI
		StringJoiner scrambled = new StringJoiner(" ");
		for(String move : scramble) {
			scrambled.add(move);
		}
		scrambleLabel = new JLabel(scrambled.toString());
		scrambleLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		scrambleLabel.setBounds(58, 118, 523, 56);
		getContentPane().add(scrambleLabel);
		
		// Image Icons for Start and Stop Button
		ImageIcon startIcon = new ImageIcon("Images/StartButton.jpg");
		ImageIcon stopIcon = new ImageIcon("Images/StopButton.jpg");
		
		// Button to start timer when solving rubik's cube
		startButton = new JButton("Start", startIcon);
		startButton.setBounds(138, 234, 117, 29);
		getContentPane().add(startButton);
		
		// Button to stop timer after solving rubik's cube
		stopButton = new JButton("Stop", stopIcon);
		stopButton.setBounds(323, 234, 117, 29);
		getContentPane().add(stopButton);
		
		// Timer
		timerLabel = new JLabel(" ");
		timerLabel.setFont(new Font("Verdana", Font.BOLD, 31));
		timerLabel.setBounds(262, 59, 117, 56);
		getContentPane().add(timerLabel);
		
		// Average Time label
		averageTimeLabel = new JLabel(" ");
		averageTimeLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		averageTimeLabel.setBounds(38, 71, 85, 35);
		getContentPane().add(averageTimeLabel);
		
		// Initialization of ArrayList times
		times = new ArrayList<Double>();
		
		
		// Instructions Label
		instructionLabel = new JLabel("Click the green button when ready to begin solving. \nClick the red button when complete.");
		instructionLabel.setFont(new Font(".AppleSystemUIFont", Font.BOLD, 11));
		instructionLabel.setBounds(28, 6, 592, 71);
		getContentPane().add(instructionLabel);
	
	
		// ActionListener class for start button
		class ButtonListener implements ActionListener{
			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getActionCommand().equals("startTimer")) {
					timer = new Timer(1000, e2 -> {
						count++;
						timerLabel.setText(Integer.toString(count));
					});
					timer.start();
	
				}
				
			}
			
		}
		
		// ActionListener class for stop button
		class ButtonListener2 implements ActionListener{

			@Override
			public void actionPerformed(ActionEvent e) {
				if(e.getActionCommand().equals("stopTimer")) {
					// Stop the time and display the resulting time when finished solving
					timer.stop();
					timerLabel.setText(Integer.toString(count));
					// Record time into ArrayList times in order to produce an average (takes at least 3 times to output an average)
					times.add((double) count);
					count = 0;
					
					// Display a new scramble to begin again
					
					scramble.clear();
					Collections.shuffle(moves);
					for(int i = 0; i < 20; i++) {
						scramble.add(moves.get(pickMoveFromList(18)));
					}
	
					for(int i = 0; i < scramble.size()-1; i++) {
						
							if(scramble.get(i).charAt(0) == scramble.get(i+1).charAt(0)) {
								scramble.set(i, moves.get(pickMoveFromList(18)));
						}
					}
					
					StringJoiner scrambled = new StringJoiner(" ");
					for(String move : scramble) {
						scrambled.add(move);
					}
					
					scrambleLabel.setText(scrambled.toString());
					
				}
				// Taking average and displaying
				Double average = 0.0;
				if(times.size() >= 3) {
					for(Double t : times) {
						average += t;
					}
					averageTimeLabel.setText("Avg: " + d.format(average/times.size()));
				}
				
			}
			
			
		}

		
		
		// Assign the buttons to execute the code from respective listeners
		startButton.setActionCommand("startTimer");
		stopButton.setActionCommand("stopTimer");
		ButtonListener myListener = new ButtonListener();
		ButtonListener2 myListener2 = new ButtonListener2();
		startButton.addActionListener(myListener);
		stopButton.addActionListener(myListener2);
		
		
	}

		
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Scrambler frame = new Scrambler();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	
	// Behavior
	
		/**
		 * Generates a random number to add a random move into ArrayList scramble
		 * 
		 * @param max - the number of possible moves (18)
		 * @return random number to grab a random move from ArrayList moves
		 */
		public static int pickMoveFromList(int max) {
			return (int) Math.floor(Math.random() * Math.floor(max));
		}
}


